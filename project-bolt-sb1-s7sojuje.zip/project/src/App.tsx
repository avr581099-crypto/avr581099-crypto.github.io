import { useState } from 'react';

function App() {
  const [showMessage, setShowMessage] = useState(false);
  const [noClicks, setNoClicks] = useState(0);

  const handleYes = () => {
    setShowMessage(true);
  };

  const handleNo = () => {
    if (noClicks < 7) {
      setNoClicks(noClicks + 1);
    } else {
      setShowMessage(true);
    }
  };

  const getYesButtonScale = () => {
    const scales = [1, 1.2, 1.4, 1.7, 2, 2.5, 3, 3.5];
    return scales[Math.min(noClicks, 7)];
  };

  const getNoButtonScale = () => {
    const scales = [1, 0.85, 0.7, 0.55, 0.4, 0.25, 0.1, 0.05];
    return scales[Math.min(noClicks, 7)];
  };

  const getNoButtonText = () => {
    if (noClicks === 0) return 'No';
    return 'Are you sure?';
  };

  if (showMessage) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center space-y-6 animate-fade-in">
          <img src="/ijolove.gif" alt="celebration" className="w-48 h-48 mx-auto" />
          <h1 className="text-5xl font-bold text-gray-800">YAY! 💕</h1>
          <p className="text-2xl text-gray-600">YAY VALENTINES WITH MY MUNNY!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white flex items-center justify-center p-4">
      <div className="text-center space-y-8">
        <img src="/jake-adventure-time.gif" alt="jake" className="w-32 h-32 mx-auto" />
        <h1 className="text-5xl md:text-6xl font-bold text-gray-800">
          Will you be my Valentine?
        </h1>
        <div className="flex gap-4 justify-center pt-8 items-center">
          <button
            onClick={handleYes}
            style={{
              transform: `scale(${getYesButtonScale()})`,
            }}
            className="px-8 py-4 bg-red-500 hover:bg-red-600 text-white font-semibold rounded-lg transition-all duration-300 shadow-lg hover:shadow-xl origin-center"
          >
            Yes
          </button>
          <button
            onClick={handleNo}
            style={{
              transform: `scale(${getNoButtonScale()})`,
            }}
            className="px-8 py-4 bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold rounded-lg transition-all duration-200 shadow-lg origin-center"
          >
            {getNoButtonText()}
          </button>
        </div>
        {noClicks > 0 && noClicks < 7 && (
          <p className="text-sm text-gray-500">
            {7 - noClicks} more click{7 - noClicks !== 1 ? 's' : ''} to reconsider...
          </p>
        )}
      </div>
    </div>
  );
}

export default App;
